import os, re, ipaddress, hashlib, sqlite3, json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
import httpx
from dotenv import load_dotenv

load_dotenv()
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("IOC_DB_PATH", BASE_DIR.parent / "data" / "investigations.db"))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
VT_API_KEY = os.getenv("VT_API_KEY", "").strip()

app = FastAPI(title="SentinelLite IOC Intelligence", version="1.0.0")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")

class AnalyzeRequest(BaseModel):
    indicator: str = Field(min_length=1, max_length=300)

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS investigations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            indicator TEXT NOT NULL,
            indicator_type TEXT NOT NULL,
            risk_score INTEGER NOT NULL,
            verdict TEXT NOT NULL,
            details TEXT NOT NULL,
            created_at TEXT NOT NULL
        )""")
init_db()

def classify_indicator(value: str):
    value = value.strip().lower()
    try:
        ip = ipaddress.ip_address(value)
        return "ip", ip
    except ValueError:
        pass
    if re.fullmatch(r"[a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{64}", value):
        return "file_hash", value
    # Deliberately conservative domain validation; no URL/path accepted.
    if len(value) <= 253 and re.fullmatch(
        r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}", value
    ):
        return "domain", value
    raise ValueError("Enter a valid IP address, domain name, or MD5/SHA1/SHA256 hash.")

async def virustotal_lookup(kind: str, value: str):
    if not VT_API_KEY:
        return None, "VirusTotal lookup skipped: VT_API_KEY is not configured."
    # VirusTotal API v3 endpoints accept IP, domain, and file hash identifiers.
    endpoint = {"ip": "ip_addresses", "domain": "domains", "file_hash": "files"}[kind]
    url = f"https://www.virustotal.com/api/v3/{endpoint}/{value}"
    try:
        async with httpx.AsyncClient(timeout=12.0) as client:
            response = await client.get(url, headers={"x-apikey": VT_API_KEY})
        if response.status_code == 404:
            return {"found": False}, "No VirusTotal record found."
        if response.status_code == 429:
            return None, "VirusTotal rate limit reached."
        if response.status_code == 401:
            return None, "VirusTotal API key was rejected."
        response.raise_for_status()
        attrs = response.json().get("data", {}).get("attributes", {})
        stats = attrs.get("last_analysis_stats", {})
        malicious = int(stats.get("malicious", 0))
        suspicious = int(stats.get("suspicious", 0))
        total = sum(int(v) for v in stats.values() if isinstance(v, (int, float)))
        return {
            "found": True,
            "malicious": malicious,
            "suspicious": suspicious,
            "undetected": int(stats.get("undetected", 0)),
            "total_engines": total,
            "reputation": attrs.get("reputation", 0),
            "last_analysis_date": attrs.get("last_analysis_date")
        }, "VirusTotal enrichment completed."
    except httpx.HTTPError:
        return None, "VirusTotal request failed; local analysis is still available."

def local_assessment(kind: str, value):
    notes = []
    score = 0
    if kind == "ip":
        ip = value
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            notes.append("Address is non-public or reserved; public reputation lookup may be unavailable.")
        else:
            notes.append("Public IP address format is valid.")
            score += 5
    elif kind == "domain":
        notes.append("Domain syntax is valid. Syntax alone does not establish maliciousness.")
        if value.startswith(("xn--",)) or value.count("-") >= 3:
            score += 10
            notes.append("Domain has characteristics worth reviewing manually.")
    else:
        notes.append(f"Valid {len(value)*4}-bit hexadecimal file hash format.")
    return score, notes

@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE_DIR / "static" / "index.html").read_text()

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "SentinelLite IOC Intelligence"}

@app.post("/api/analyze")
async def analyze(request: AnalyzeRequest):
    raw = request.indicator.strip()
    try:
        kind, normalized = classify_indicator(raw)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    value = str(normalized)
    score, notes = local_assessment(kind, normalized)
    vt_data, vt_message = await virustotal_lookup(kind, value)
    notes.append(vt_message)
    if vt_data and vt_data.get("found"):
        malicious = vt_data.get("malicious", 0)
        suspicious = vt_data.get("suspicious", 0)
        total = vt_data.get("total_engines", 0)
        if total:
            score = max(score, round(100 * (malicious + 0.5 * suspicious) / total))
        notes.append(f"VirusTotal engines: {malicious} malicious, {suspicious} suspicious, {total} reporting.")
    score = max(0, min(100, score))
    verdict = "High risk" if score >= 70 else "Needs review" if score >= 25 else "No strong signal"
    created = datetime.now(timezone.utc).isoformat()
    details = {"notes": notes, "virustotal": vt_data}
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute(
            "INSERT INTO investigations (indicator, indicator_type, risk_score, verdict, details, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (value, kind, score, verdict, json.dumps(details), created)
        )
        record_id = cur.lastrowid
    return {"id": record_id, "indicator": value, "type": kind, "risk_score": score,
            "verdict": verdict, "notes": notes, "virustotal": vt_data, "created_at": created,
            "disclaimer": "A low score is not proof of safety. Validate findings with additional evidence."}

@app.get("/api/investigations")
def investigations(limit: int = 20):
    limit = max(1, min(limit, 100))
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT id, indicator, indicator_type, risk_score, verdict, created_at FROM investigations ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()
    return [dict(row) for row in rows]

@app.get("/api/investigations/{record_id}")
def investigation_detail(record_id: int):
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT * FROM investigations WHERE id = ?", (record_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Investigation not found")
    result = dict(row)
    result["details"] = json.loads(result["details"])
    return result
