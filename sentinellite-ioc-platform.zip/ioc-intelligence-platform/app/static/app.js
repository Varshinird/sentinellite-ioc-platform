const form = document.getElementById("analyze-form");
const input = document.getElementById("indicator");
const button = document.getElementById("analyze-btn");
const result = document.getElementById("result");
const errorBox = document.getElementById("error");
const historyBody = document.getElementById("history");

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function showError(message) {
  errorBox.textContent = message;
  errorBox.classList.remove("hidden");
  result.classList.add("hidden");
}
function renderResult(data) {
  const vt = data.virustotal && data.virustotal.found
    ? `<p>VirusTotal: <b>${data.virustotal.malicious}</b> malicious / ${data.virustotal.total_engines} engines</p>`
    : "";
  result.innerHTML = `
    <div class="result-top"><div><p class="eyebrow">INVESTIGATION #${data.id}</p><h2>${escapeHtml(data.indicator)}</h2><p class="muted">${escapeHtml(data.type)} · ${escapeHtml(data.verdict)}</p></div><div class="score">${data.risk_score}/100</div></div>
    ${vt}<ul class="notes">${data.notes.map(n=>`<li>${escapeHtml(n)}</li>`).join("")}</ul>
    <p class="hint">${escapeHtml(data.disclaimer)}</p>`;
  result.classList.remove("hidden");
  errorBox.classList.add("hidden");
}
async function loadHistory() {
  try {
    const response = await fetch("/api/investigations");
    const rows = await response.json();
    document.getElementById("case-count").textContent = rows.length;
    historyBody.innerHTML = rows.length ? rows.map(row => `
      <tr><td>${escapeHtml(row.indicator)}</td><td>${escapeHtml(row.indicator_type)}</td>
      <td>${row.risk_score}/100</td><td class="${row.risk_score>=70?'high':row.risk_score>=25?'risk':''}">${escapeHtml(row.verdict)}</td>
      <td>${new Date(row.created_at).toLocaleString()}</td></tr>`).join("")
      : '<tr><td colspan="5" class="empty">No investigations yet. Analyze an IOC to begin.</td></tr>';
  } catch { historyBody.innerHTML = '<tr><td colspan="5" class="empty">Could not load history.</td></tr>'; }
}
form.addEventListener("submit", async event => {
  event.preventDefault();
  button.disabled = true;
  button.textContent = "ANALYZING…";
  errorBox.classList.add("hidden");
  try {
    const response = await fetch("/api/analyze", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({indicator:input.value})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "Analysis failed.");
    renderResult(data);
    await loadHistory();
  } catch (error) { showError(error.message); }
  finally { button.disabled = false; button.innerHTML = 'ANALYZE IOC <span>→</span>'; }
});
document.getElementById("refresh").addEventListener("click", loadHistory);
fetch("/api/health").then(r=>r.json()).then(d=>{if(d.status==="ok")document.getElementById("intel-status").textContent="LOCAL + API READY";}).catch(()=>{});
loadHistory();
